
produtos = []

def adicionar_produto():
    nome = input("Nome do produto: ")
    preco = float(input("Preço: "))
    estoque = int(input("Estoque: "))
    produto = {"nome": nome, "preco": preco, "estoque": estoque}
    produtos.append(produto)
    print(f"{nome} adicionado com sucesso!\n")

def listar_produtos():
    print("\n=== Lista de Produtos ===")
    for i, p in enumerate(produtos, 1):
        print(f"{i}. Nome: {p['nome']}, Preço: R${p['preco']:.2f}, Estoque: {p['estoque']}")
    print()

def menu():
    while True:
        print("1 - Adicionar Produto")
        print("2 - Listar Produtos")
        print("0 - Sair")
        escolha = input("Escolha: ")
        if escolha == "1":
            adicionar_produto()
        elif escolha == "2":
            listar_produtos()
        elif escolha == "0":
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    menu()
