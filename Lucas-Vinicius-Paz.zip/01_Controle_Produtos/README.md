# 01 - Controle de Produtos
Sistema simples de controle de produtos em Python.

**Como rodar:**
```bash
python main.py
```
**Exemplo de saída:**
```
=== Lista de Produtos ===
1. Nome: Camiseta, Preço: R$39.99, Estoque: 50
```
