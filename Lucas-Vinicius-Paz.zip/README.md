# Lucas Vinicius Paz
Portfólio com projetos em Python, POO e ML.

## Projetos
- 01_Controle_Produtos
- 02_Biblioteca_Python
- 03_POO_Python
- 04_ML_Iris

Links: [GitHub](https://github.com/Lusca-31/Lucas-Vinicius-Paz)