# 03 - POO em Python
Sistema de gerenciamento de livros usando POO.

**Como rodar:**
```bash
python main.py
```
**Exemplo de saída:**
```
1984 (1949) - George Orwell
O Pequeno Príncipe (1943) - Antoine de Saint-Exupéry
```
