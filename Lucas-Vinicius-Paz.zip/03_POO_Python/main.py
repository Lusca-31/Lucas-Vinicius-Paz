
class Livro:
    def __init__(self, titulo, autor, ano):
        self.titulo = titulo
        self.autor = autor
        self.ano = ano

    def __str__(self):
        return f"{self.titulo} ({self.ano}) - {self.autor}"

class Biblioteca:
    def __init__(self):
        self.livros = []

    def adicionar_livro(self, livro):
        self.livros.append(livro)
        print(f"{livro.titulo} adicionado à biblioteca!")

    def listar_livros(self):
        print("\n=== Livros na Biblioteca ===")
        for livro in self.livros:
            print(livro)

if __name__ == "__main__":
    b = Biblioteca()
    b.adicionar_livro(Livro("1984", "George Orwell", 1949))
    b.adicionar_livro(Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry", 1943))
    b.listar_livros()
